package com.maximus.otccamera

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCode = 4107
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(0xFF090B10.toInt())
        }
        val title = TextView(this).apply {
            text = "MAXIMUS OTC CAMERA GOLD"
            textSize = 24f
            setTextColor(0xFFFFD76A.toInt())
        }
        status = TextView(this).apply {
            text = "جاهز — اضغط بدء مشاركة الشاشة"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "بدء مشاركة الشاشة"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف الالتقاط"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "تم طلب إيقاف الالتقاط"
            }
        }
        layout.addView(title); layout.addView(status); layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }

    @Deprecated("Activity result API can be adopted in a later revision")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "بدأ الالتقاط بعد موافقتك. سيظهر إشعار دائم أثناء المشاركة."
        } else {
            status.text = "لم تتم الموافقة على مشاركة الشاشة."
        }
    }
}
